#include <iostream>
using namespace std;
int main() {
  cout << "Hello World!\n";
  cout<<"potwierdzam obecnosc na zajeciach"<<endl;
}